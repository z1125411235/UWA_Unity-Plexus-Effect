# Plexus effect for Unity

Effect created for Unity particle system, based on [Mirza Beig's](https://www.youtube.com/user/TheMirzaBeig) tutorial. 

![alt text](https://github.com/Caedo/UnityPlexusEffect/blob/master/Particle%20gif2.gif)
